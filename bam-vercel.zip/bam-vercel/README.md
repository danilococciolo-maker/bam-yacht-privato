# BAM Yacht v5.0

## Deploy su Vercel (solo dal browser iPad, niente terminale)

### 1. Crea repo GitHub
1. Apri Safari su iPad, vai su https://github.com/new
2. Repository name: `bam-yacht`
3. Visibility: Private (consigliato)
4. NON aggiungere README/gitignore
5. Tap "Create repository"

### 2. Carica i 3 file in GitHub
1. Nella pagina del repo appena creato, tap "uploading an existing file"
2. Tap "choose your files" e seleziona dall'app Files:
   - `index.html`
   - `api/replicate.js` (importante: la cartella `api` deve essere preservata - vedi sotto)
   - `vercel.json`
3. Per assicurarti che `api/replicate.js` finisca dentro la cartella `api/`, prima di committare scrivi nel campo "Drag additional files here" il path completo. In alternativa: usa l'app web GitHub che permette di trascinare cartelle intere. Se non riesci, dopo aver caricato `replicate.js` rinominalo da "..." menu in `api/replicate.js`.
4. Commit message: "Initial commit"
5. Tap "Commit changes"

### 3. Connetti a Vercel
1. Vai su https://vercel.com/new
2. Import Git Repository → seleziona `bam-yacht`
3. Lascia tutte le impostazioni di default
4. Tap "Deploy"
5. Attendi ~1 minuto

### 4. Apri l'URL Vercel
Vercel ti darà un URL tipo `bam-yacht-xyz.vercel.app`. Aprilo.

### 5. Configura token Replicate
1. Tap sull'icona ⚙️ in alto a sinistra
2. Incolla il tuo token Replicate (`r8_...`)
3. Salva

### 6. Test
Carica una foto interna di yacht, scegli stile, "Genera Concept Refit". Dovrebbe funzionare al primo colpo.

## Cosa è cambiato rispetto a v4.x
- **Niente più vision step**: era il responsabile dei 404, ora rimosso completamente
- **Hosting Vercel**: niente più copy-paste fragile dell'editor Val.town
- **Pipeline più corta**: 3 step invece di 5 (load → canny → upscale)
- **Prompt rinforzato**: ogni stile inizia con "preserve all windows exactly as in input"
